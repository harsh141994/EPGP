package com.epgp.inflibnet.epgp.model;

public class Subject {
	
	private String id;
	private String pi_name;
	private String designation_affilation;
	private String anchor_institute;
	private String subject;
	private String emailid;
	private String phone_number;
	private String static_module;
	private String four_module;

	public String getAnchor_institute() {
		return anchor_institute;
	}

	public void setAnchor_institute(String anchor_institute) {
		this.anchor_institute = anchor_institute;
	}

	public String getDesignation_affilation() {
		return designation_affilation;
	}

	public void setDesignation_affilation(String designation_affilation) {
		this.designation_affilation = designation_affilation;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getFour_module() {
		return four_module;
	}

	public void setFour_module(String four_module) {
		this.four_module = four_module;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}

	public String getPi_name() {
		return pi_name;
	}

	public void setPi_name(String pi_name) {
		this.pi_name = pi_name;
	}

	public String getStatic_module() {
		return static_module;
	}

	public void setStatic_module(String static_module) {
		this.static_module = static_module;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}
}
